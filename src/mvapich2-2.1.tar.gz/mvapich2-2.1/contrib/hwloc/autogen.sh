:
autoreconf ${autoreconf_args:-"-ivf"}
